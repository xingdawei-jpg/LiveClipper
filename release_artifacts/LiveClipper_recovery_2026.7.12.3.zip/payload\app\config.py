# ============================================================
# 配置文件 2026.4.26：关键词瘦身 + 按类型差异化时长 + 短且多
# ============================================================

# 用户数据目录（更新不丢失配置）
import json
import os
import re


def _default_user_data_dir():
    return os.path.join(os.environ.get('APPDATA', os.path.expanduser('~')), 'LiveClipper')


def _location_file():
    return os.path.join(_default_user_data_dir(), 'user_data_location.json')


def _normalize_user_data_dir(path):
    text = str(path or '').strip().strip('"')
    if not text:
        return _default_user_data_dir()
    return os.path.abspath(os.path.expanduser(os.path.expandvars(text)))


def _configured_user_data_dir():
    env_path = os.environ.get('LIVECLIPPER_USER_DATA_DIR')
    if env_path:
        return _normalize_user_data_dir(env_path)
    try:
        pointer = _location_file()
        if os.path.exists(pointer):
            with open(pointer, 'r', encoding='utf-8-sig') as f:
                data = json.load(f)
            custom = data.get('user_data_dir') if isinstance(data, dict) else ''
            if custom:
                return _normalize_user_data_dir(custom)
    except Exception:
        pass
    return _default_user_data_dir()


def set_user_data_dir(path):
    global USER_DATA_DIR, SETTINGS_PATH
    target = _normalize_user_data_dir(path)
    os.makedirs(target, exist_ok=True)
    default = _normalize_user_data_dir(_default_user_data_dir())
    os.makedirs(default, exist_ok=True)
    pointer = _location_file()
    if os.path.normcase(target) == os.path.normcase(default):
        try:
            if os.path.exists(pointer):
                os.remove(pointer)
        except Exception:
            pass
    else:
        with open(pointer, 'w', encoding='utf-8') as f:
            json.dump({'user_data_dir': target}, f, ensure_ascii=False, indent=2)
    USER_DATA_DIR = target
    SETTINGS_PATH = os.path.join(USER_DATA_DIR, 'ai_settings.json')
    return USER_DATA_DIR


USER_DATA_DIR = _configured_user_data_dir()
SETTINGS_PATH = os.path.join(USER_DATA_DIR, 'ai_settings.json')

# 一、片段类型 → 关键词分级（精简版：每词只归属一个类型，职责清晰）
CLIP_KEYWORDS = {
    "hook": {
        "keywords": [
            # 爆料型(最强停留)
            "假的", "行业秘密", "全都是假的", "不敢信",
            # 痛点直呼(精准锁客)
            "微胖", "腿粗", "拜拜肉", "小个子", "大骨架", "肩宽",
            # 信任承诺
            "盲拍", "闭眼入", "不搞虚",
            # 极强情绪(只留最强，删泛夸奖)
            "绝了", "封神", "yyds", "绝绝子", "美爆",
            # 重复强调(最强情绪信号)
            "超级超级", "特别特别", "真的真的", "非常非常",
            # 触感爆点(精简，只留最强体验词)
            "太舒服", "太软了", "冰冰凉凉", "跟面膜一样",
            # 包容承诺
            "我不管", "想怎么穿", "随便你",
        ],
        "weight": 35,
        "description": "开场抓人(爆料/痛点/承诺/强情绪/触感)",
    },
    "product": {
        "keywords": [
            # 痛点解决(最强转化)
            "绝对可以穿", "也能穿", "穿得进去", "不用担心", "放心",
            # 对比突出(精简重复)
            "比市面上", "外面卖", "专柜", "大牌平替",
            # 面料维度
            "面料", "垂感", "亲肤", "透气", "抗皱", "软糯", "手感",
            # 版型维度
            "收腰", "开叉", "弹力", "修身", "松紧腰", "包容性", "高腰线",
            # 品质维度
            "做工", "走线", "不起球", "内衬", "刺绣", "蕾丝",
            # 上身效果
            "上身", "版型",
        ],
        "weight": 25,
        "description": "产品种草(痛点解决/对比/面料/版型/品质)",
    },
    "close": {
        "keywords": [
            # 尺码指导
            "尺码", "卡码", "往小拍", "往大拍", "推荐尺码",
            # 购买指令
            "直接拍", "小黄车", "左下角",
            "冲", "抢", "入手", "下单",
        ],
        "weight": 35,
        "description": "促单收尾(尺码/购买指令/优惠)",
    },
    "bridge": {
        "keywords": [
            "教你", "辨别", "怎么看", "区别", "真假",
            "为什么", "原因是", "是因为",
        ],
        "weight": 15,
        "description": "过渡衔接(科普/提问，可选)",
    },
    "trend": {
        "keywords": [
            "流行色", "当季", "新款", "复古风", "韩系", "法式",
            "设计款", "原创", "不撞款", "独家",
            "今年流行", "今年最火", "秀场",
        ],
        "weight": 10,
        "description": "流行趋势(可选)",
    },
}

# 黄金链路（新结构：3必选 + 2可选）
CLIP_ORDER = [
    "hook", "bridge", "product", "close", "trend",
]

# 兜底用简单链路
SIMPLE_CHAIN = ["hook", "product", "close"]


# 黄金链路（7环节，严格顺序）
CLIP_ORDER = [
    "hook", "bridge", "product", "close", "trend",
]

# ============================================================
# 二、前置数据清洗（OpenClaw 执行，绝不喂给模型）
# ============================================================

# 禁止进入候选池的内容（仅绝对垃圾，不过杀）
BAN_PATTERNS = [
    r"再开新款", r"过下一个", r"过款", r"接下来", r"好吧",
    r"就这样", r"我先占", r"你们等一下", r"等一下",
    r"感谢关注", r"喝水", r"点关注",
    r"\d+[件条套个]",  # 纯数量描述如 "3件"、"5条"、"2套"
    r"福利", r"直播间", r"号链接", r"链接",
    r"关注一下", r"点关注",
]

# 淘汰级关键词（仅短文本时负分）
NEGATIVE_KEYWORDS = [
    "好看", "不错", "舒服", "挺好", "网红款",
]

# 废话填充词（清理用，不作为过滤条件）
FILLER_WORDS = [
    "啊", "呃", "嗯", "那个", "就是", "然后", "那个啥",
    "对吧", "是吧", "所以说", "你知道吗", "我跟你说",
    "这样子的", "的话",

    "呕", "嗯", "对不对", "对吧", "然后",
]

# 负面信号
NEGATIVE_SIGNALS = [
    "是不是", "能不能", "好不好", "会不会", "对不对",
    "不知道", "不清楚", "抱歉", "不好意思", "稍等", "卡了",
    "听不见", "看不到", "断线",
    "倒计时", "321", "上链接", "原价", "成交价", "特惠",
    "截图抽奖", "下播前", "马上要下",
]

NEGATION_WORDS = ["不", "没", "别", "不是", "不会", "不能", "没有"]

# 情绪加分词
EMOTION_WORDS = {
    "exclaim": ["！", "!", "天呐", "哇", "绝了", "太", "超", "超级", "真"],
    "contrast": ["别家没有", "只有我家", "独款", "独家"],
    "action": ["抢", "冲", "闭眼入", "直接拍", "入手", "上车"],
}

# 违禁词替换表
PROHIBITED_WORDS = {
    "最": "爆款", "顶级": "人气款", "唯一": "专属款",
    "减肥": "修饰身形", "瘦腿": "修饰腿型", "塑形": "贴合身形",
    "100%纯羊绒": "羊绒质感", "纯羊毛": "羊毛混纺", "纯棉": "棉感面料",
    "不跑绒": "不易跑绒", "不掉色": "不易掉色", "不起球": "不易起球",
    "跳楼价": "限时特惠", "亏本甩卖": "福利价", "全网最低": "到手价",
    "必买": "热卖推荐", "必囤": "人气款",
}

# 候选池准入门槛（松紧平衡，不过杀）
CANDIDATE_MIN_LENGTH = 5    # 字数≥5（带货口语5字就够）
CANDIDATE_MIN_DURATION = 1.5  # 时长≥1.5秒
CANDIDATE_MAX_DURATION = 12   # 时长≤12秒


# ASR 修正映射（常见识别错误 → 正确词）
ASR_CORRECTIONS = {
    '汗麻': '汉麻',       # 汗麻→汉麻
    '不补单': '不补货',   # 不补单→不补货
    '天撕': '天丝',       # 天撕→天丝
    '马内': '麻类',       # 马内→麻类
    '马解': '麻刺',       # 马解→麻刺
}

# 违禁词(GUI关键词管理用, 命中则移除片段)
FORBIDDEN_PHRASES = [
    # ===== 销量数据类 =====
    "一万多件", "两万件", "三万件", "八千件", "九千件",
    "卖了", "销量", "订单", "件了", "单了",
    # ===== 极限词类 =====
    "最", "绝了", "太美了", "太好看了",
    "超好看", "无敌", "全网", "顶级", "极品",
    "回馈率最高", "最好", "最强", "最具",
    # ===== 绝对化用语 =====
    "绝对是", "肯定是", "必须是",
    "保证", "承诺", "包你", "效果",
    # ===== 违禁促销词 =====
    "特价", "特惠", "大促", "狂减", "秒杀",
    "仅此一天", "最后一天", "限量", "限时",
    "跳楼价", "亏本", "清仓", "底价",
    # ===== 不文明用语 =====
    "牛逼", "吹牛逼", "傻逼", "他妈", "尼玛",
    # ===== 效果对比 =====
    "前后对比", "瘦了", "白了", "变了",
    "以前", "现在", "效果明显",
    # ===== 品牌侵权相关 =====
    "正品", "专柜", "原单", "尾单",
    "同款", "大牌", "国际大牌",
    # ===== 原有过滤词 =====
    "再开新款", "过下一个", "过款", "接下来",
    "好吧", "就这样", "我先占", "你们等一下", "等一下",
    "感谢关注", "喝水", "点关注",
    # 价格/促销相关
    "破价", "限时价", "秒杀价", "福利价", "到手价", "开团价",
    "优惠", "折扣", "领券", "立减", "满减",
    "价格", "购物车", "一号链接", "二号链接", "上链接", "上连结", "上連結", "连结", "連結", "链接拍",
    "321", "3 2 1", "三二一", "321上车", "上车了", "刷新", "去拍", "赶紧拍",
]

STRICT_FORBIDDEN_PHRASES = [
    # 材质/成分类
    "纯棉", "真丝", "真皮", "牛皮", "羊毛", "羊绒", "桑蚕丝", "蚕丝", "羽绒服", "兔绒毛", "丝绸",
    # 防晒/检测/数值承诺
    "防晒值", "防晒值upf+", "UPF", "upf", "UPF+", "upf+", "紫外线隔热99%", "紫外线隔热", "隔热99%",
    # 等级/材质安全/功能宣称
    "食品级", "母婴级", "304", "316", "纳米", "抗菌", "抑菌", "除菌", "杀菌", "灭菌", "无菌", "防菌", "消菌", "菌",
    # 药品/农药/绝对化/销量
    "药方", "杀虫剂喷雾", "杀虫剂", "高级", "首选", "全网销量第一", "销量50万+", "销量50万",
    # 严重违禁与功效类
    "丰胸", "增高", "减肥", "壮阳", "功效", "疗效", "药效", "治疗", "治愈", "改善", "调理", "祛湿", "排毒",
    # 促销导流/互动引导
    "价格", "点关注", "满减", "领券", "321", "3 2 1", "三二一", "链接", "上链接", "上连结", "上連結", "连结", "連結",
    # 迷信宗教类
    "开运", "转运", "招财", "辟邪", "风水", "佛牌", "算命", "占卜", "改命", "消灾", "祈福", "迷信", "宗教",
]

def forbidden_phrase_list(extra_phrases=None):
    words = []
    if extra_phrases:
        words.extend(str(item).strip() for item in extra_phrases if str(item).strip())
    words.extend(STRICT_FORBIDDEN_PHRASES)
    return list(dict.fromkeys(words))


def sanitize_forbidden_title(text, extra_phrases=None, fallback="未命名商品"):
    value = str(text or "")
    for word in sorted(forbidden_phrase_list(extra_phrases), key=len, reverse=True):
        if word:
            value = value.replace(word, "")
    value = re.sub(r"\s+", " ", value)
    value = re.sub(r"[_\-\s]{2,}", " ", value)
    value = value.strip(" _-，,。.;；:：|/\\")
    return value or fallback
# ============================================================
# 三、文案优化配置
# ============================================================
TEXT_OPTIMIZATION = {
    "max_length": 45,
    "min_length": 5,
    "end_punctuation": "！",
    "remove_patterns": [r"^那个", r"^就是", r"^然后", r"^嗯", r"^啊"],
}

# ============================================================
# 四、视频参数
# ============================================================
VIDEO_CONFIG = {
    "resolution": "1080:1920", "fps": 30,
    "bitrate_v": "5M", "bitrate_a": "192k",
    "codec_v": "libx264", "preset": "fast",
    "codec_a": "aac", "format": "mp4",
}

import os, sys, shutil
def _find_ffmpeg():
    if getattr(sys, 'frozen', False):
        base = os.path.dirname(sys.executable)
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    local = os.path.join(base, "ffmpeg", "ffmpeg.exe")
    if os.path.exists(local):
        return local
    # PyInstaller bundled: _internal/ffmpeg/ffmpeg.exe
    internal = os.path.join(base, "_internal", "ffmpeg", "ffmpeg.exe")
    if os.path.exists(internal):
        return internal
    found = shutil.which("ffmpeg")
    if found:
        return found
    for p in [r"C:\ffmpeg\bin\ffmpeg.exe", r"D:\ffmpeg\bin\ffmpeg.exe"]:
        if os.path.exists(p):
            return p
    return None

FFMPEG_PATH = _find_ffmpeg()

# ============================================================
# 五、视频去重策略
# ============================================================
DEDUP_CONFIG = {
    # === 增强版去重配置 v2.0 ===
    # 核心策略: 镜像 + 随机变速(保音调) + 随机微裁剪 + 音频微pitch
    "random_count": 1,  # 不再用随机选择，改用固定增强链路
    "strategy": "enhanced",  # enhanced = 增强版全链路

    # 镜像配置
    "mirror": {
        "enabled": True,
        "type": "horizontal",  # 水平镜像（保护女装展示，禁用垂直）
    },

    # 随机变速配置（保音调核心）
    "variable_speed": {
        "enabled": True,
        "min_rate": 1.10,
        "max_rate": 1.30,
        "decimal_precision": 2,
        # 加权随机：1.1-1.2x 占70%（人声自然），1.2-1.3x 占30%（强效去重）
        "weight_low": 0.7,   # 1.1~1.2x 概率
        "weight_high": 0.3,  # 1.2~1.3x 概率
        "audio_pitch_lock": False,  # 不保音调，用 atempo 纯变速（音质好）
        "fallback_speed": 1.15,    # 异常兜底速率
    },

    # 随机微裁剪（3%以内，不碰主体）
    "random_crop": {
        "enabled": True,
        "crop_min": 0.97,
        "crop_max": 0.99,
        "offset_min": 0.005,
        "offset_max": 0.015,
    },

    # 音频微pitch（增强音纹去重）
    "audio_pitch": {
        "enabled": True,
        "min_pitch": -1.5,  # 音高微降1.5%
        "max_pitch": 2.0,   # 音高微升2.0%
    },

    # === 新增去重方法 v2.1 ===
    # 等级1：轻量消重（0画质损失）
    "gamma_shift": {
        "enabled": True,    # 伽马微调
        "range": (-0.02, 0.02),  # ±0.02 肉眼看不出
    },

    # 等级2：中阶消重
    "corner_mask": {
        "enabled": True,    # 四角微遮罩
        "size_pct": 0.005,  # 0.5% 角标大小
        "color": "0x000000",  # 黑色（也可以用画面主色）
    },
    "audio_reverb": {
        "enabled": True,    # 极轻微混响改变音纹
        "probability": 0.5, # 50%概率启用
    },

    # 等级3：高阶消重
    "noise_fusion": {
        "enabled": True,    # 双音轨融合（原音+极轻白噪音）
        "noise_volume": 0.001,  # 噪音音量（极轻）
        "probability": 0.4, # 40%概率启用
    },
    "frame_interpolation": {
        "enabled": False,   # 单帧插值（minterpolate很慢，默认关闭）
        "mode": "blend",    # blend模式无卡顿
        "probability": 0.3,
    },

    # 原有方法保留但默认关闭（enhanced模式不使用）
    "methods": {
        "speed_change": {"enabled": False},
        "zoom_crop": {"enabled": False},
        "mirror": {"enabled": False},
        "frame_drop": {"enabled": False},
        "color_shift": {"enabled": False},
        "rotation": {"enabled": False},
        "noise": {"enabled": False},
        "pixel_shift": {"enabled": False},
        "edge_blur": {"enabled": False},
        "audio_pitch_old": {"enabled": False},
    },
}
DEDUP_PRESET = "medium"

# ============================================================
# 六、字幕叠加配置
# ============================================================
SUBTITLE_OVERLAY = {
    "enabled": True,
    "font_name": None,  # 运行时从 platform_config 获取
    "font_size": 52,
    "font_color": "&H00FFFFFF",
    "outline_color": "&H00000000",
    "outline_width": 0,
    "position": "bottom",
    "margin_v": 350,
    "keyword_font_size": 112,
    "keyword_font_color": "&H0000FFFF",
    "keyword_bold": True,
}

SUBTITLE_KEYWORDS = [
    "99", "199", "299", "229", "159", "399", "49", "69", "129", "189", "259",
    "元", "块", "到手", "价格", "领券", "优惠", "省",
    "绝了", "太好", "超好看", "惊艳", "漂亮", "高级", "质感",
    "爆款", "必入", "闭眼入", "冲", "绝美", "无敌",
    "没货", "抢", "卖光", "后悔", "断码", "321", "库存",
    "面料", "垂感", "不起球", "高腰", "显瘦", "弹力",
]

# ============================================================
# 七、时长目标
# ============================================================
# 七、时长目标（按类型差异化）
TARGET_DURATION = 60
TARGET_DURATION_TOLERANCE = 10
# 按类型的片段时长范围（Hook短爆点 / Product深种草 / Close果断收）
CLIP_DURATION_BY_TYPE = {
    "hook": (2, 5),      # 短爆点，2-5秒
    "product": (4, 9),    # 种草需要深度，4-9秒
    "close": (3, 6),      # 果断收尾，3-6秒
    "bridge": (3, 6),     # 过渡，3-6秒
    "trend": (3, 6),      # 趋势，3-6秒
}
# 兼容旧代码的全局范围（取所有类型的并集）
CLIP_DURATION_RANGE = (2, 9)
MIN_TOTAL_CLIPS = 10
REQUIRED_CLIP_TYPES = ["hook", "close"]
# 按类型的建议片段数量
CLIP_COUNT_BY_TYPE = {
    "hook": (1, 2),       # 1-2个Hook
    "product": (6, 10),   # 6-10个Product（短而精，多角度种草）
    "close": (1, 2),      # 1-2个Close
    "bridge": (0, 1),     # 可选
    "trend": (0, 1),      # 可选
}
TIME_WINDOW_MINUTES = 8

# ============================================================
# 主题系统 — 跟随 Windows 深色/浅色模式
# ============================================================
import winreg as _wr

def _is_dark_mode():
    """检测 Windows 系统是否为深色模式"""
    try:
        key = _wr.OpenKey(_wr.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize")
        val, _ = _wr.QueryValueEx(key, "AppsUseLightTheme")
        _wr.CloseKey(key)
        return val == 0  # 0=深色, 1=浅色
    except:
        return True  # 默认深色

# 深色主题（简洁现代）
_DARK = {
    "bg": "#1C1C1E", "card": "#2C2C3A", "text": "#F5F5F5", "dim": "#8E8E93",
    "ok": "#30D158", "warn": "#FF9F0A", "err": "#FF453A", "inp": "#3A3A4D",
    "bar": "#0A84FF", "btn_go": "#0A84FF", "btn_no": "#FF453A", "btn_sel": "#0A84FF", "btn_go2": "#0A84FF", "btn_del": "#63687A", "card_border": "#3A3A52", "bar_bg": "#3A3A4D",
}

# 浅色主题（简洁现代）  
_LIGHT = {
    "bg": "#F2F2F7", "card": "#FFFFFF", "text": "#1C1C1E", "dim": "#8E8E93",
    "ok": "#34C759", "warn": "#FF9500", "err": "#FF3B30", "inp": "#E5E5EA",
    "bar": "#007AFF", "btn_go": "#007AFF", "btn_no": "#FF3B30", "btn_sel": "#007AFF", "btn_go2": "#007AFF", "btn_del": "#C7C7CC", "card_border": "#D1D1D6", "bar_bg": "#D1D1D6",
}

# 根据系统主题选择配色
C = _DARK

# 字体
FNT_S = ("Microsoft YaHei", 10)
FNT_B = ("Microsoft YaHei", 12, "bold")
