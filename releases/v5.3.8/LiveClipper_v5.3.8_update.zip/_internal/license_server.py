"""
激活码管理系统 - 服务端（部署在你的服务器/VPS上）
使用方式：python license_server.py

功能：
- 生成激活码
- 验证激活码
- 管理用户（激活/停用/续期）
- 下发 API Key（不暴露给客户端）

数据存储：licenses.json（同一个目录下自动创建）

部署建议：
- 放到你的 VPS/云服务器上
- 用 nginx 反向代理加 HTTPS
- 或者直接用 Python 起一个 HTTPS 服务

启动方式：
  python license_server.py [--port 8080] [--host 0.0.0.0]

API 端点：
  POST /api/verify     - 验证激活码
  POST /api/config     - 获取配置（API Key等）
"""

import json
import os
import sys
import time
import hashlib
import secrets
import argparse
from http.server import HTTPServer, BaseHTTPRequestHandler

# ============================================================
# 配置
# ============================================================
SERVER_PORT = 8080
DB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "licenses.json")
# 服务端密钥（用于签名，防止客户端伪造）
SERVER_SECRET = "CHANGE_ME_TO_A_RANDOM_STRING_2026"

# ============================================================
# 数据库管理
# ============================================================

def _load_db():
    """加载用户数据库"""
    if not os.path.exists(DB_FILE):
        return {"users": {}, "admin_key": "admin123"}
    with open(DB_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _save_db(db):
    """保存用户数据库"""
    with open(DB_FILE, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)


def generate_license(days=30, plan="monthly"):
    """
    生成激活码
    days: 有效天数（30=月卡, 365=年卡）
    plan: 套餐类型
    返回: (激活码, 用户信息)
    """
    db = _load_db()

    # 生成 16 位激活码（XXXX-XXXX-XXXX-XXXX 格式）
    code = "-".join(secrets.token_hex(4).upper() for _ in range(4))

    now = int(time.time())
    user = {
        "code": code,
        "plan": plan,
        "activated_at": None,
        "expires_at": None,
        "status": "unused",  # unused / active / expired / disabled
        "machine_id": None,  # 绑定的机器码（一码一机）
        "days": days,
        "created_at": now,
    }
    db["users"][code] = user
    _save_db(db)
    return code, user


def activate_license(code, machine_id):
    """激活码激活（首次使用时调用）"""
    db = _load_db()

    if code not in db["users"]:
        return {"ok": False, "msg": "激活码不存在"}

    user = db["users"][code]

    if user["status"] == "disabled":
        return {"ok": False, "msg": "激活码已被禁用"}

    if user["status"] == "expired":
        return {"ok": False, "msg": "激活码已过期"}

    # 如果已绑定其他机器
    if user["machine_id"] and user["machine_id"] != machine_id:
        return {"ok": False, "msg": "激活码已绑定其他设备"}

    now = int(time.time())
    user["activated_at"] = now
    user["expires_at"] = now + user["days"] * 86400
    user["status"] = "active"
    user["machine_id"] = machine_id
    db["users"][code] = user
    _save_db(db)

    return {"ok": True, "msg": "激活成功", "expires_at": user["expires_at"]}


def verify_license(code, machine_id):
    """
    验证激活码
    返回: {ok, msg, config, expires_at, days_left}
    """
    db = _load_db()

    if code not in db["users"]:
        return {"ok": False, "msg": "激活码不存在"}

    user = db["users"][code]

    if user["status"] == "disabled":
        return {"ok": False, "msg": "激活码已被禁用"}

    if user["status"] == "expired":
        return {"ok": False, "msg": "激活码已过期"}

    if user["status"] == "active":
        now = int(time.time())
        if now > user["expires_at"]:
            user["status"] = "expired"
            db["users"][code] = user
            _save_db(db)
            return {"ok": False, "msg": "激活码已过期"}

        # 验证机器绑定
        if user["machine_id"] and user["machine_id"] != machine_id:
            return {"ok": False, "msg": "激活码已绑定其他设备"}

        days_left = (user["expires_at"] - now) / 86400

        return {
            "ok": True,
            "msg": "验证通过",
            "expires_at": user["expires_at"],
            "days_left": round(days_left, 1),
        }

    return {"ok": False, "msg": "激活码尚未激活"}


def get_config(code):
    """
    获取客户端配置（验证通过后调用）
    API Key 等敏感信息通过此接口下发，不写死在客户端
    """
    db = _load_db()

    if code not in db["users"]:
        return {"ok": False, "msg": "无效"}

    user = db["users"][code]
    if user["status"] != "active":
        return {"ok": False, "msg": "激活码未激活或已过期"}

    now = int(time.time())
    if now > user["expires_at"]:
        user["status"] = "expired"
        db["users"][code] = user
        _save_db(db)
        return {"ok": False, "msg": "激活码已过期"}

    # 生成签名，防止客户端伪造
    sign_str = f"{code}:{user['expires_at']}:{SERVER_SECRET}"
    signature = hashlib.md5(sign_str.encode()).hexdigest()[:16]

    return {
        "ok": True,
        "config": {
            "api_key": "ec3351cf-2694-46a7-92ec-bc2087d80281",
            "base_url": "https://ark.cn-beijing.volces.com/api/v3",
            "model": "doubao-1-5-pro-32k-250115",
            "asr_enabled": False,
        },
        "signature": signature,
    }


# ============================================================
# HTTP 服务
# ============================================================

class LicenseHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        """自定义日志格式"""
        print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {args[0]}")

    def _send_json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        body = self.rfile.read(length)
        return json.loads(body.decode("utf-8"))

    def do_POST(self):
        try:
            data = self._read_body()

            if self.path == "/api/verify":
                code = data.get("code", "")
                machine_id = data.get("machine_id", "")
                if not code or not machine_id:
                    self._send_json({"ok": False, "msg": "参数缺失"})
                    return

                result = verify_license(code, machine_id)
                self._send_json(result)

            elif self.path == "/api/activate":
                code = data.get("code", "")
                machine_id = data.get("machine_id", "")
                if not code or not machine_id:
                    self._send_json({"ok": False, "msg": "参数缺失"})
                    return

                result = activate_license(code, machine_id)
                self._send_json(result)

            elif self.path == "/api/config":
                code = data.get("code", "")
                if not code:
                    self._send_json({"ok": False, "msg": "参数缺失"})
                    return

                result = get_config(code)
                self._send_json(result)

            else:
                self._send_json({"ok": False, "msg": "未知接口"}, 404)

        except Exception as e:
            self._send_json({"ok": False, "msg": f"服务器错误: {e}"}, 500)


# ============================================================
# 命令行管理工具
# ============================================================

def cmd_generate(args):
    """生成激活码"""
    days = args.days
    plan = args.plan
    count = args.count
    codes = []
    for _ in range(count):
        code, user = generate_license(days, plan)
        codes.append(code)
        print(f"  {code}  |  {plan} |  {days}天")

    print(f"\n共生成 {len(codes)} 个激活码")


def cmd_list(args):
    """列出所有激活码"""
    db = _load_db()
    users = db.get("users", {})
    if not users:
        print("没有激活码")
        return

    now = int(time.time())
    print(f"{'激活码':<24} {'状态':<10} {'套餐':<10} {'剩余天数':<10} {'机器码':<20}")
    print("-" * 80)

    for code, user in sorted(users.items(), key=lambda x: -x[1].get("created_at", 0)):
        status = user.get("status", "unknown")
        plan = user.get("plan", "-")
        machine = user.get("machine_id", "-")[:16] if user.get("machine_id") else "-"

        if status == "active" and user.get("expires_at"):
            days_left = (user["expires_at"] - now) / 86400
            days_str = f"{days_left:.0f}天"
        elif status == "expired":
            days_str = "已过期"
        else:
            days_str = "-"

        print(f"{code:<24} {status:<10} {plan:<10} {days_str:<10} {machine:<20}")


def cmd_disable(args):
    """禁用激活码"""
    db = _load_db()
    code = args.code.upper()
    if code not in db["users"]:
        print(f"激活码 {code} 不存在")
        return
    db["users"][code]["status"] = "disabled"
    _save_db(db)
    print(f"已禁用: {code}")


def cmd_enable(args):
    """启用激活码"""
    db = _load_db()
    code = args.code.upper()
    if code not in db["users"]:
        print(f"激活码 {code} 不存在")
        return
    user = db["users"][code]
    if user["status"] == "expired":
        print("激活码已过期，请生成新的")
        return
    user["status"] = "active"
    _save_db(db)
    print(f"已启用: {code}")


def main():
    global SERVER_SECRET
    parser = argparse.ArgumentParser(description="直播切片工具 - 激活码管理系统")
    sub = parser.add_subparsers(dest="command")

    # 服务启动
    srv = sub.add_parser("serve", help="启动验证服务器")
    srv.add_argument("--port", type=int, default=SERVER_PORT)
    srv.add_argument("--host", default="0.0.0.0")
    srv.add_argument("--secret", default=None, help="服务端密钥（必须修改）")

    # 生成激活码
    gen = sub.add_parser("generate", help="生成激活码")
    gen.add_argument("--days", type=int, default=30, help="有效天数")
    gen.add_argument("--plan", default="monthly", help="套餐: monthly/yearly")
    gen.add_argument("--count", type=int, default=1, help="生成数量")

    # 列出激活码
    sub.add_parser("list", help="列出所有激活码")

    # 禁用/启用
    dis = sub.add_parser("disable", help="禁用激活码")
    dis.add_argument("code", help="激活码")
    en = sub.add_parser("enable", help="启用激活码")
    en.add_argument("code", help="激活码")

    args = parser.parse_args()

    if args.command == "serve":
        if args.secret:
            SERVER_SECRET = args.secret
        elif SERVER_SECRET == "CHANGE_ME_TO_A_RANDOM_STRING_2026":
            print("⚠️  警告：请修改 SERVER_SECRET（服务端密钥）！")
            print("   python license_server.py serve --secret YOUR_RANDOM_STRING")
            return

        server = HTTPServer((args.host, args.port), LicenseHandler)
        print(f"🚀 激活码验证服务器启动")
        print(f"   地址: http://{args.host}:{args.port}")
        print(f"   接口: /api/verify, /api/activate, /api/config")
        print(f"   密钥已设置: {'是' if args.secret else '否（请设置！）'}")
        print("")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\n服务器已停止")

    elif args.command == "generate":
        cmd_generate(args)
    elif args.command == "list":
        cmd_list(args)
    elif args.command == "disable":
        cmd_disable(args)
    elif args.command == "enable":
        cmd_enable(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
